BetFriend: Meta top-of-funnel static ads (8 ads x 3 sizes)
==========================================================

Live preview: https://macaroniidev.github.io/betfriend-prototype/ads/tof/

Folders and files
- creatives/S1 ... S8/   each ad in three sizes:
    -1x1.jpg  (1080x1080)  Facebook/Instagram feed
    -4x5.jpg  (1080x1350)  feed (recommended)
    -9x16.jpg (1080x1920)  Stories/Reels (Meta safe zones kept clear)
- ads.csv     primary text, headline, description, button and link for every ad (opens in Excel/Sheets)
- ads.json    the same, plus the ad set, why it should get the click, and the math behind every number
- test-plan.md            launch order, budgets, kill/scale rules
- competitor-analysis.md  research behind the ads (858 competitor Meta ads)

Ad sets (ABO, 2 ads each): 1 Bonus to cash = S1+S2 | 2 Sportsbook enemy = S3+S4 | 3 Curiosity = S5+S6 | 4 Native social = S7+S8
Native style: no logo or button in the image (Meta adds the button); only a small 21+ line.

In Ads Manager: upload the 4:5 image for Feed and the 9:16 image for Stories/Reels placements
(use "placement asset customization"), paste the primary text/headline/description from ads.csv,
and use the URL column as the website URL ({{site_source_name}} is a Meta URL parameter).

Before spending: install the Meta pixel + Conversions API, connect a real checkout, use an owned domain,
get Meta's online-gambling authorization, confirm prices, and have a public source ready for
"sportsbooks limit winners" (S3, S5). Every dollar figure is labelled "Example".
