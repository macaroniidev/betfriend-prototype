BetFriend: Meta top-of-funnel static ads (8 ads x 3 sizes)
==========================================================

Live preview: https://macaroniidev.github.io/betfriend-prototype/ads/tof/

Folders and files
- creatives/S1 ... S8/   each ad in three sizes:
    -1x1.jpg  (1080x1080)  Facebook/Instagram feed
    -4x5.jpg  (1080x1350)  feed (recommended)
    -9x16.jpg (1080x1920)  Stories/Reels (Meta safe zones kept clear)
- ads.csv     primary text, headline, description, button and link for every ad (opens in Excel/Sheets)
- ads.json    the same, plus the angle, why it should get the click, and the math behind every number
- test-plan.md            launch order, budgets, kill/scale rules
- competitor-analysis.md  research behind the ads (858 competitor Meta ads)

Launch order: S1, S2, S3 first; then S4-S8. S8 is the backup if Meta rejects S1.

In Ads Manager: upload the 4:5 image for Feed and the 9:16 image for Stories/Reels placements
(use "placement asset customization"), paste the primary text/headline/description from ads.csv,
and use the URL column as the website URL ({{site_source_name}} is a Meta URL parameter).

Before spending: install the Meta pixel + Conversions API, connect a real checkout, use an owned domain,
get Meta's online-gambling authorization, confirm prices/handle, and add a public source for
"sportsbooks can limit bettors who win" (S2). Every dollar figure is labelled "Example".
