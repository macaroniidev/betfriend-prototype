BetFriend: Meta top-of-funnel static ads (16 ads x 2 sizes)
==========================================================

Live preview: https://macaroniidev.github.io/betfriend-prototype/ads/tof/

Folders and files
- creatives/S1 ... S16/   each ad in two sizes:
    -4x5.jpg  (1080x1350)  Facebook Feed + Instagram Feed
    -9x16.jpg (1080x1920)  Facebook Reels + Instagram Reels (Reels safe zones kept clear: top 14%, bottom 35%, right edge)
- KIAN-SETUP.txt  step-by-step Ads Manager setup with every ad's exact copy
All ad links go to https://betfriend.bet
- ads.csv     primary text, headline, description, button and link for every ad (opens in Excel/Sheets)
- ads.json    the same, plus the ad set, why it should get the click, and the math behind every number
- test-plan.md            budgets, what to measure, kill/scale rules for this static test
- competitor-analysis.md  research behind the ads (858 competitor Meta ads)

Ad sets (ABO, 4 ads each, $45/day each):
  1 Bonus to cash     = S1, S2, S9, S10
  2 Sportsbook enemy  = S3, S4, S11, S12
  3 Curiosity         = S5, S6, S13, S14
  4 Native social     = S7, S8, S15, S16
S9-S16 are written for beginners and prediction-market users who don't know these money tricks exist.
Native style: no logo or button in the image (Meta adds the button); only a small 21+ line.

Placements: manual, ONLY Facebook Feed, Instagram Feed, Facebook Reels, Instagram Reels.
In Ads Manager: 4:5 image for both Feeds, 9:16 image for both Reels (placement asset customization), paste the primary text/headline/description from ads.csv,
and use the URL column as the website URL ({{site_source_name}} is a Meta URL parameter).

Before spending: install the Meta pixel + Conversions API, connect a real checkout, finish setting up betfriend.bet (landing page live there),
get Meta's online-gambling authorization, confirm prices, and have a public source ready for
"sportsbooks limit winners" (S3, S5). Every dollar figure is labelled "Example".
