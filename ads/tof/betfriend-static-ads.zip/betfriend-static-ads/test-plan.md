# TOF round 2: test plan

**Goal:** find the hooks that make cold US bettors stop, watch and click. Cost per trial is judged later, once the pixel is live (see `../prespend-checklist.md`).
**Set:** 8 concepts (`ads.json`). One of them, U1, is a creator system: one ad text with three hook videos (U1, U1b, U1c).

## Structure
- **Campaign:** one prospecting campaign, objective Sales or Leads (Traffic until the pixel and Conversions API exist). US only, 21+, Advantage+ audience, Advantage+ placements, with Reels and Stories kept on.
- **Ad sets:** each video concept and the statics get their own ad set, or use ABO with equal budgets, so Meta can't starve a concept on day 1.

| Ad set | Ads | Daily budget |
|---|---|---|
| A, creator system | U1, U1b, U1c (same primary text) | 3 × [BUDGET_UNIT] |
| B, roast my parlay | U2 | [BUDGET_UNIT] |
| C, sportsbook limits skit | U3 | [BUDGET_UNIT] |
| D, anti-tout | U6 | [BUDGET_UNIT] |
| E, street quiz | U5 | [BUDGET_UNIT] |
| F, statics | Q4, C4, Q3 (Meta rotates) | [BUDGET_UNIT] |

Suggested [BUDGET_UNIT]: about $40–60/day, enough for roughly 3–5k impressions per ad per day at typical US betting CPMs. Benchmark CPMs are an assumption to check in week 1.

## Launch order
1. **Day 1:** ad sets A, B and C. These are the critic's top 3 (U1 7.85, U2 7.75, U3 7.70).
2. **Day 3:** D, E and F, once A–C have a baseline CPM and hook rate.
3. **Alternates if Meta rejects an ad:** Q1 (bonus receipt), C3 (parlay slips), C7 ("knowing ball"). Specs are in `concepts.md`.

## What to measure (per ad, after 3,000+ impressions)
| Metric | Definition | Kill | Keep | Scale |
|---|---|---|---|---|
| Hook rate | 3s video plays ÷ impressions | < 20% | 25–35% | > 35% |
| Hold rate | ThruPlays ÷ 3s plays | < 15% | 20–30% | > 30% |
| CTR (link) | link clicks ÷ impressions | < 0.6% | 0.8–1.5% | > 1.5% |
| CPC (link) | spend ÷ link clicks | > 2× set median | — | < set median |
| Landing view rate | LPV ÷ link clicks | < 60% (fix page speed / message match) | — | — |
| Comments / shares per 1k impr. | engagement depth (virality proxy) | — | — | top quartile = pick for creator remakes |

These thresholds are working benchmarks for cold paid social. Re-baseline them after week 1 against the set's own median.

## Rules
- **No early edits:** don't judge or edit inside 48h or under 3,000 impressions per ad. Edits reset learning.
- **Kill:** an ad that misses two "Kill" thresholds after 3,000 impressions.
- **Scale:** raise the budget of an ad set whose ads beat "Scale" on hook rate **and** CTR by 20–30% every 48h. Duplicate the winning ad into a fresh ad set rather than raising budget by more than 2× at once.
- **Creator system (A):** keep the primary text fixed. Each week, add 2–3 new hook videos and cut the worst. This mirrors Linemate's 68-copy system, the strongest scaling signal in the competitor data.
- **Winning angle:** remake it in a second format (video → static, or static → video) before declaring it a winner. Formats age at different speeds.
- **Fatigue:** when frequency passes 2.5 or CTR drops 30% from its peak, rotate in new hooks on the same angle.

## Iteration cadence
- **Week 1:** find the winning angle (enemy/limits vs bonus → cash vs parlay price vs anti-tout vs quiz).
- **Week 2:** make 4–6 new hooks on the top two angles, then add Spanish versions of the best one (no competitor runs Spanish ads; see `competitor-analysis.md`).
- **Week 3+:** once there are ~50 trial starts per week, move optimisation to the trial event and judge on cost per trial.

## Before spending
Every blocker in `../prespend-checklist.md` still applies:
- pixel and Conversions API
- a working checkout
- an owned domain
- Meta gambling authorization
- confirmed prices and handle

Also check every [VERIFY] note in `concepts.md`:
- the sportsbook-limits source for U3 and U1b
- the prediction-market fee schedule for Q3
