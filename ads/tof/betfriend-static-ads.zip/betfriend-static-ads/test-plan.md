# BetFriend static ads: test plan

**Goal:** find the angles and native formats that get cold US bettors and prediction-market users to click, at the lowest cost per click. Judge on cost per trial once the pixel tracks trial starts.

## Setup
- **Campaign:** one campaign, ABO.
- **Budget:** 4 ad sets × $45/day = $180/day. The remaining $20/day is held back to scale the first winner.
- **Placements:** manual, only Facebook Feed, Instagram Feed, Facebook Reels and Instagram Reels.
  - Feeds use the 4:5 image.
  - Reels use the 9:16 image, with the Reels safe zones kept clear.
- **Audience:** US (or the states Meta approves), age 21–65+, broad.
- **Links:** all ads go to `https://betfriend.bet` with UTM tags (`utm_content` = ad ID).

| Ad set | Angle | Ads |
|---|---|---|
| 1 | Bonus to cash | S1, S2, S9, S10 |
| 2 | Sportsbook enemy | S3, S4, S11, S12 |
| 3 | Curiosity (incl. prediction markets) | S5, S6, S13, S14 |
| 4 | Native social (chats, threads) | S7, S8, S15, S16 |

## Rules
- **No early changes:** no edits, budget changes or new ads for the first 72 hours.
- **When to judge an ad:** only after 3,000+ impressions.

| Metric | Turn off | Keep | Winner |
|---|---|---|---|
| Link CTR | < 0.8% | 0.8–2% | > 2% |
| CPC (link) | > 2× ad set average | — | lowest in account |
| Landing page view rate | < 60% of clicks (check page speed) | — | — |

These are working benchmarks for native statics on cold traffic. Re-baseline after the first week against the account's own median.

- **Ad set off:** if all of an ad set's ads are off, pause it and move its $45 to the winning ad set's best ad, duplicated into a new ad set.
- **Scaling:** raise a winning ad set's budget by no more than 20% every 48 hours, or duplicate the winner into a fresh $45 ad set.
- **Fatigue:** when frequency goes above 2.5 or CTR drops 30% from its peak, add new versions of the winning angle in a different native format (for example, a chat version of a notes winner).
- **Comments:** the controversial ads (S3, S4, S11) will draw comments. Reply to real questions; hide only spam and abuse.

## Week 2
- Make 4 new ads on the best-performing angle and 2 on the second best.
- Turn the best static into a Reels video (creator talking head), since Reels is already a placement.

## Before launch
- **Domain:** `betfriend.bet` is live and the landing page loads there, including the `?h=promo`, `#how`, `#prediction` and `#arbitrage` variants the ads use.
- **Tracking:** the Meta pixel and Conversions API are installed, the `betfriend.bet` domain is verified in Business Manager, and the trial event is set up.
- **Approval:** Meta's online-gambling authorization is approved.
- **Proof on file:** have a public source ready for "sportsbooks limit winners" (S3, S5, S11).
