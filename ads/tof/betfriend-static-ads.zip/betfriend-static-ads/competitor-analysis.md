# Competitor Meta ad analysis for BetFriend TOF (2026-10-27)

**Bottom line.** Four patterns have both staying power and scale behind them:
1. **Anti-tout "math, not picks"** expert clips (OddsJam, 53 days live).
2. **"Since when is this a thing?" UGC app reveals** at volume (Linemate, 68 ad IDs on 60 different videos).
3. **Cheap authority statics** (PlayerProps.ai, 97 days live).
4. **"Your sportsbook is taking a cut" money math** (Novig, Kalshi).

Nobody advertises bonus-bet conversion, middles, the all-in-one bundle, or a sportsbook-vs-prediction-market price check. Those are BetFriend's openings.

Evidence tags: **[O]** = observed in the data, **[I]** = inferred from proxies. Meta publishes no spend or CTR, so every performance call names its proxy:
- **L** = longevity
- **D** = duplication
- **R** = `impr_rank`
- **V** = variants or placements

---

## 1. Method and data coverage

### Sources

| Source | Rows kept | What it is | Limits |
|---|---|---|---|
| metapi `metapi-2026-10-27` | 761 | Meta Ad Library, sorted by total impressions per advertiser. Capped at 150 (Kalshi, Polymarket). | `active` is **false on every row**, so it is unusable. I treat an ad as **live when `stop` ≥ 2026-10-26**: Meta stamps the pull date as `stop` for running ads. `collation_count` is empty on all metapi rows. |
| ScrapeCreators `scrapecreators-2026-10-01` | 97 | Snapshot of active ads on 10-01 for Juice Reel, OddsJam, Outlier, Rithmm and The Action Network. | 26 days old. Prior research found all 12 OddsJam rows from this snapshot **off by 10-14**. No `impr_rank`. |
| Dropped | 120 | **Tyler Tometich** (60 ads selling the "Viral VFX" video course, viral-strategies.com) and **Arthur Reynolds** (60 ads for grounding sheets and melatonin, groundingwell.com). | Off-topic, confirmed from copy and links. |

### Creatives reviewed

- I viewed 42 six-frame video strips (every relevant strip in `frames/`) and 18 preview thumbnails I downloaded for high-signal ads that had no media. That covers Hot Hand, PlayerProps.ai, Kalshi, Polymarket, Novig and Flare.
- I read all 42 relevant Whisper transcripts.
- I built on the prior OddsJam ad-by-ad verdicts (`oddsjam-lp/docs/bf/oddsjam/options-ads.json`), `oddsjam-lp/.firecrawl/cr/raw/analysis.md` and `rithmm-research.md`.

### Limits

- **No spend, CTR or reach.** `impr_rank` is a within-advertiser order of lifetime impressions. It favours older ads and is not comparable across advertisers.
- **The 150-row cap hides new, low-impression ads** for Kalshi and Polymarket. Polymarket shows 0 live in its top 150, but keyword discovery on 10-27 still surfaced a Polymarket "Who's winning the Midterms? … code FREE25" ad. So Polymarket is running, just not with its top-impression creatives.
- Video asset IDs decoded from the fbcdn `efg` parameter tell me whether duplicate ad IDs share one video. Image-only duplicates were compared by filename.

### Who is and isn't advertising on Meta right now (finding)

| Status on 10-27 | Advertisers |
|---|---|
| **Live and scaling** | Linemate (77 live), Kalshi (66+), The Hot Hand (52), Novig (25), PlayerProps.ai (21), Flare Got Locks (16), OddsJam (15), Juice Reel (11 in metapi; 25 on 10-01), Dimers (9), Wise Guy Team (6), LVLup Props (4, 1 day old), Parlay Bully (4) |
| **Live but outside the top-150 impressions sample** | Polymarket (Midterms ads seen in discovery) |
| **Dark now, active on 10-01** | **Rithmm** (21 live on 10-01; 29 per Foreplay on 10-15; 0 returned on 10-27). **The Action Network** (36 DCO ads on 10-01, all one Polymarket affiliate offer; 0 now). |
| **Dead or abandoned** | Outlier (all ads ended; prior research found `AD_ACCOUNT_DISABLED` after jackpot-parlay creatives), YRL Sports (90 ads, all dead in June, World Cup tout), Live Score 5 (March), Betzy AI (June–July), edge__maxxer (Feb), Stats Bench (Jan, Jun) |
| **Not found on Meta** | BetQL, OddsShopper, Leans.AI and Unabated (searches returned only off-topic pages). Pikkit had 4 hits but no betting page in the discovery list. |

**What this means [I]:**
- The paid-social category for betting *tools* is thin. Only 3 tool brands have ads past 30 days: OddsJam, PlayerProps.ai and Flare. The adjacent prediction markets (Kalshi, Novig) outspend everyone and are warming the same cold audience.
- Rithmm going dark mid-NFL season either means it is moving channels or its test matrix failed. It leaves the "AI analyst" lane on Meta empty.

---

## 2. Who's spending

"Live" means `stop` ≥ 10-26 (metapi), or active on 10-01 for scrape-only advertisers.

| Advertiser | Group | Rows | Live 10-27 | Longest live runner | Biggest duplication cluster (same body) | Formats / placements |
|---|---|---|---|---|---|---|
| **Kalshi** | prediction mkt (adjacent) | 150 | 66 | 75 d (3210928545758290) | 24 ("Trade on sports… $2,000 code 2KSIGNUP"); 20 ("Trade on anything… Live across the U.S.") | Video, median 21 s, Audience Network on 70% of ads |
| **Linemate** | props research | 91 | 77 | 19 d (1442130230816788) | **68** ("Stop Research. Start Winning.") on 60 distinct videos | UGC video, median 21 s, FB/IG/Threads |
| **The Hot Hand** | tout | 66 | 52 | 8 d | 19 + 14 + 13 + 5 ("STOP PAYING FOR PICKS…") | Static-style video, Messenger "Send message" CTA, FB/IG only |
| **Novig** | exchange (adjacent) | 37 | 25 | 26 d (2045714676083061) | 17 ("Stop just watching the games. Trade them.") | Video, median 15 s, plus image cards |
| **PlayerProps.ai** | props research | 26 | 21 | **97 d** (2517698648671454 + 4 more) | 14 ("Most awarded betting research App of 2025!") | 8 s motion-static plus creator video |
| **Flare Got Locks** | tout / community | 19 | 16 | **81 d** (1611633220679010, rank 1) | 3 bodies on 1 video | Static plus 10 s selfie video, whop.com lander |
| **OddsJam** | odds tools | 30 | 15 | 53 d (3934320263531311, 3113507032374176, 2527583204414029, 2637327576706685) | 17 ("Bet Both Sides And Win Either Way!") | Talking head / podcast, median 41 s, 21+ line burned in |
| **Juice Reel** | AI picks / tracker | 36 | 11 (25 on 10-01) | 20 d (1380191140817120, rank 1) | 15 ("See more than a screenshot…") | Creator video plus image, separate iOS and Android ads |
| **Dimers** | AI picks | 11 | 9 | 29 d (1117400790634759, rank 1) | 5 on one concept ("…don't need more picks") | 1 image + 3 videos (25, 37, 49 s) on one body |
| **Wise Guy Team** | tout / sharp | 6 | 6 | 12 d | 6 on 2 AI-avatar videos | AI presenter, 26–30 s |
| **Polymarket** | prediction mkt (adjacent) | 150 | 0 in top 150 | 141 d ever (501837323000166) | **40** ("…If there's a winner, there's a market") and 23 ("Think you know who's winning the World Cup?") | Video plus market-card images |
| **The Action Network** | media → affiliate | 36 | 0 (36 on 10-01) | 1 d | **36** DCO ("Football markets are open") | DCO, 15 collation groups, Polymarket affiliate link |
| **Rithmm** | AI picks | 21 | 0 (21 on 10-01) | 12 d | 2 | Creator, motion graphics, AI chat demo; App Store |
| Outlier / YRL / Live Score 5 / Betzy / Stats Bench / edge__maxxer / LVLup / Parlay Bully | various | 4–90 | 0–4 | ≤ 4 d (Outlier 17 d before ban) | YRL 21, Live Score 19 | Mostly short-lived bursts |

---

## 3. Top 20 winning concepts

Direct competitors are ranked first. Adjacent prediction markets are ranked separately (A1–A6).

| # | Concept | Advertiser | Key ad IDs | Strongest proxy |
|---|---|---|---|---|
| 1 | "Watching sports won't make you money": anti-tout expert podcast clip | OddsJam | 3934320263531311, 3113507032374176, 2527583204414029 | **L**: live 53 d, the longest live OddsJam ads, 3 of 4 survivors from the 09-04 batch |
| 2 | "Since when is this a thing?" UGC app reveal | Linemate | 1406597501675165, 3443366169158393, 1680903836948505, 2200740734118560, 1812882866522088 | **D**: 68 IDs, 60 videos, 54 live; **R** = 1 |
| 3 | "Most awarded betting research app" authority static | PlayerProps.ai | 2517698648671454, 1516143260267486, 1555696532961020 | **L**: 97 d; **D**: 14 copies, 11 live |
| 4 | Worked arb with a verified P&L ("I've made $6,000…") | OddsJam | 2637327576706685 (siblings 1843009947141985, 2898032990565903) | **L**: 53 d live; siblings stopped at 51 d |
| 5 | "Fake handicappers / stop trusting screenshots" | Juice Reel | 1380191140817120, 1577049383583610, 1341229307942214 | **R** = 1–2; **D**: relaunched as a new ID on 10-26 |
| 6 | Honest anti-hype ("Most people quit in a week") | OddsJam | 1848819836287088, 1142396211784609, 3758436740970442, 1086246544013560, 948654587836314, 1726262205731896 | **D**: 6+ IDs; **R** 6–11; **L** up to 25 d |
| 7 | "Check the matchup. Open the chat. Then turn the game on." | Flare Got Locks | 1611633220679010 | **L**: 81 d live; **R** = 1 |
| 8 | "You don't need more picks, you need a faster way to find value" | Dimers | 1117400790634759, 2151353115454307, 1084295807306655, 1721952176601874 | **R** = 1; **L** 29 d; **V**: 4 formats on one body |
| 9 | NBA injury report on a lock screen (arb) | OddsJam | 1631510528693064, 2586824065129954 | **R** = 2–3 at 14 d |
| 10 | "This guy won no matter what happened" (relaunch) | OddsJam | 1857891308958690 | **R** = 1 at only 6 d |
| 11 | "How are people spotting NBA props that haven't missed?" | Linemate | 1395804959209935 + 9 | **D**: 10 IDs on 9 videos in 3 days |
| 12 | "Find the few pick sellers who actually win" + auto-tail | Juice Reel | 1643820760952279, 1146084687902097 | **R** 4–5; **D**: 15-copy body |
| 13 | "Every service wants your card first. We do it backwards." | Wise Guy Team | 1883584836261303, 952458930820477 | **D**: 6 IDs on 2 AI avatars |
| 14 | "STOP PAYING FOR PICKS": DM for free picks | The Hot Hand | 2350443975757292, 1109896431529434, 981193461042494 | **D**: 51 IDs, but **L** ≤ 8 d (churn) |
| A1 | "I made money because it snowed last night" skit | Kalshi | 1072959668952666, 1090154740139516 | **L**: 43 d; **R** 6–7; same video, iOS and Android |
| A2 | "Trade on anything / sports. Live across the U.S." market cards | Kalshi | 4592154017778575, 2113101326224523, 3210928545758290 | **D**: 20 + 16 IDs; **L** to 75 d; **R** = 1 |
| A3 | "Think you know who's winning ___?" topic-swap template | Polymarket | 901664116182050 + 22; 1453173183208842; 1157683096324155 | **D**: 23 + 18 + 6 + 6 IDs; **R** = 1 |
| A4 | "POV: your sportsbook every time you play: it's just 30%" | Novig | 1865955564395349 | **R** 3; **L** 20 d live |
| A5 | "Stop just watching the games. Trade them." + $50 + celebrity | Novig | 2641150729681511, 2045714676083061 | **D**: 17 IDs; **R** = 1; **L** 26 d |
| A6 | Payout math: "Don't overthink it. 49ers at 9%, $100 pays $1,044" | Kalshi | 1822717462190341, 2193569014538154 | **R** 8–12; **L** 17–18 d (ended) |

### Concept cards

**1. OddsJam: "Watching sports won't make you money"**
- **Ad IDs:** 3934320263531311, 3113507032374176 and 2527583204414029, live 53 d. 1577964853800807 stopped on 10-25 at 51 d.
- **0–3 s hook:**
  - Visual: podcast mic, founder in profile. Huge yellow-and-white caption "WATCHING SPORTS WON'T MAKE YOU MONEY" over sportsbook-lounge b-roll. 21+/1-800-GAMBLER line from frame 1.
  - Spoken: "For 99% of people watching sports does not make them a better sports bettor." Sibling hooks are "…really stupid" and "insanely gullible".
- **Angle:** you lose because of price, not picks, so stop buying picks.
- **Emotional trigger:** ego threat plus insider contrarianism.
- **Format:** 39–50 s podcast clip, karaoke captions.
- **Evidence:** the longest live ads at the market's only real odds-tool advertiser. They outlived every arbitrage demo from the same 09-04 launch. Lifetime rank is 12–15 because the October batch is newer and hotter.
- **Why it works:** it filters for people who already bet, flatters the viewer who "reads", and needs no product shot until late.
- **How to beat it:** BetFriend has no famous founder, so use a credentialed pro or ex-book trader. End on a *live* number from the product (a +EV bet on tonight's slate), not just a philosophy.

**2. Linemate: "Since when is this a thing?" UGC**
- **Ad IDs:** 1406597501675165 (rank 1), 3443366169158393, 1680903836948505, 2200740734118560, 1812882866522088, 3632588200233666, 1619176226417980.
- **0–3 s hook:**
  - Visual: Snapchat-style grey caption bar, "SORRY since when was this a thing??💀", "3 YEARS building parlays and NOW I FIND THIS?!", "when did this come out…?". A shirtless or hoodie creator gives a stunned face-to-camera reaction, then the phone is shown in hand.
  - Spoken: "Am I seeing this right?" / "No way."
- **Angle:** accidental discovery of a parlay and cheat-sheet generator.
- **Emotional trigger:** FOMO plus "insider secret".
- **Format:** selfie UGC, 11–52 s, at least 6 different creators (viewed), tapping through the app on a real phone.
- **Evidence:** 68 ad IDs, 60 distinct video assets, 1 body, 1 headline, launched in batches (21 on 10-08, 28 on 10-13, 6 on 10-22). 54 are live, ranks 1–10 [O].
- **Why it works:** it looks like an organic Snap or TikTok post. Meta finds winners across 60 shots while the copy stays constant.
- **How to beat it:** the same engine, but each creator "discovers" a *different* BetFriend tool (arb, middles, promo converter, sharp money). Twenty-five tools give 25 natural reveal stories, which Linemate can't match.

**3. PlayerProps.ai: "Most awarded betting research app of 2025!"**
- **Ad IDs:** 2517698648671454, 1516143260267486, 2543762462742360, 1903763663629735 and 2549463665517356 (all 97 d), 1555696532961020 (81 d).
- **0–3 s hook (static or 8 s motion):**
  - "New MLB spread predictor goes 15-0!" over a list of picks with % confidence (2517698648671454).
  - A creator pointing at "500,000+ bettors taught. STOP LOSING. Learn for free →" (1555696532961020).
- **Angle:** authority and social proof, plus a free start.
- **Emotional trigger:** trust plus loss aversion.
- **Evidence:** the longest live ads of any betting tool (97 d). 14 copies, 11 live, split iOS/Android on a shared `collation_id` (1002848225998140) [O].
- **Why it works:** cheap and fatigue-resistant. One claim is readable in 1 s, and it runs on Messenger and Audience Network inventory.
- **How to beat it:** an honest authority claim BetFriend can own: "25 betting tools. One app. 7 days free." Use product UI, not "15-0" records, which are unverifiable and risky.

**4. OddsJam: worked arb with a verified P&L**
- **Ad ID:** 2637327576706685, live 53 d. Siblings 1843009947141985 and 2898032990565903 stopped on 10-25 at 51 d.
- **0–3 s hook:**
  - Spoken: "I've made $6,000 betting on the NFL, and I'm going to show you the exact strategy."
  - Visual: creator over a Pikkit "Verified" profit card (prior research).
- **Angle:** one real game, two books, two stakes, profit either way.
- **Emotional trigger:** greed with safety.
- **Format:** 41 s talking head plus screen.
- **Evidence:** **L** 53 d. Later batches cloned this format.
- **Why it works:** the mechanism is understood in 10 s, and third-party proof beats screenshots.
- **How to beat it:** use the same worked-example template on the **promo converter** ("I turned a $250 bonus bet into $180 cash before kickoff"). Every cold sportsbook user has a bonus, but not everyone wants to arb.

**5. Juice Reel: "Fake handicappers / stop trusting screenshots"**
- **Ad IDs:** 1380191140817120 (rank 1, 20 d), 1577049383583610 (rank 2, 20 d), 1341229307942214 (same copy relaunched 10-26).
- **0–3 s hook:**
  - Visual: a jester-clown emoji over a guy carrying cash at a sportsbook window, with the caption "This app exposes fake handicappers 🫣". Or a 40-something creator in a "NOT GEN POP" hoodie at home.
  - Spoken: "Tired of losing money trusting fake online betting profits?" / "How many handicappers selling picks on Instagram are full of BS… all 90%."
- **Angle:** verified, sportsbook-synced records.
- **Emotional trigger:** anger at being scammed, plus vindication.
- **Format:** reaction overlay and rant UGC, 40–42 s.
- **Evidence:** **R** 1–2 at 20 d; **D**: the winner was re-cut into a new ID.
- **Why it works:** a shared enemy that every bettor recognises.
- **How to beat it:** BetFriend's *pro bettor signals* plus transparency. "We show every signal's full record, losers included." Aim it at the tout, not the viewer.

**6. OddsJam: honest anti-hype ("Most people who try this quit in a week")**
- **Ad IDs:** 1848819836287088 (rank 10, 25 d), 1142396211784609 (rank 11), 3758436740970442, 1086246544013560, 1726262205731896, 948654587836314.
- **0–3 s hook:**
  - Visual: wide-eyed creator on a green "matrix of odds" background, with terminal-font captions "MOST PEOPLE / QUIT IN A WEEK." Cuts to the arb screen at 6 s.
  - Spoken: "Most people who try this quit in a week, here's why."
- **Angle:** reverse psychology and qualification.
- **Emotional trigger:** challenge ("are you the type?").
- **Evidence:** **D** 6+ IDs within 3 weeks, ranks 6–11. 948654587836314 is still marked live but last delivered on 10-19 per prior research.
- **Why it works:** it pre-empts the "too good to be true" objection that kills arb ads.
- **How to beat it:** pair the honesty with a time cost ("It takes 12 minutes a night. Here's the 12 minutes."). Use it as a mid-funnel follow-up, not as the first touch.

**7. Flare Got Locks: "Check the matchup. Open the chat. Then turn the game on."**
- **Ad ID:** 1611633220679010, live 81 d, rank 1.
- **0–3 s hook:** an editorial static of a dark man-cave with floating chat bubbles ("What are we watching tonight?") under the RWTW crown logo, with big yellow condensed type. A sibling static, 3483459311815995 (110 d, ended), reads "MONEY KEEPS COMING IN WHEN THE PROCESS STAYS THE SAME."
- **Angle:** belonging and a second screen, not picks.
- **Emotional trigger:** belonging plus game-day ritual.
- **Evidence:** the longest live direct-category ad with rank 1.
- **Why it works:** community framing avoids "picks" claims and the policy friction that comes with them.
- **How to beat it:** BetFriend's **live AI analysis** as the game-day second screen: "Turn the game on. Turn BetFriend on." Show live line moves and AI reads instead of a chat room.

**8. Dimers: "Most bettors don't need more picks"**
- **Ad IDs:** 1117400790634759 (image, rank 1, 29 d), 2151353115454307 (49 s), 1084295807306655 (25 s), 1721952176601874 (37 s).
- **0–3 s hook:**
  - Visual: an analyst over a sportsbook board screenshot. Red wash at 6 s, then a green rising chart.
  - Spoken: "Sportsbooks set thousands of lines every single week… a few are going to be a little off."
- **Angle:** model vs line equals value, with an honest "not a guarantee".
- **Emotional trigger:** competence.
- **Evidence:** **R** 1; **L** 29 d; one body tested as 1 image and 3 video cuts. 1654394262963124 adds "compares sportsbook data **and prediction-market prices**", the only competitor touching that angle.
- **How to beat it:** show the gap as a number on a real game in the first 2 s, not after a 10 s explanation.

**9. OddsJam: NBA injury report on a lock screen**
- **Ad IDs:** 1631510528693064 (rank 2), 2586824065129954 (rank 3, a twin on another lander).
- **0–3 s hook:**
  - Visual: an iPhone lock screen reading "Tuesday, October 20 · 7:00". The spoken words arrive as **OddsJam push notifications**, then an "Injury report" notification appears. Creator in a cap below.
  - Spoken: "If you bet the NBA off vibes, keep scrolling. This is for the people who read the injury report."
- **Angle:** news creates price gaps for minutes.
- **Emotional trigger:** urgency plus being in the know.
- **Evidence:** **R** 2–3 within 14 d.
- **Why it works:** the notification UI is native and thumb-stopping, and it dramatises speed.
- **How to beat it:** the lock-screen device suits BetFriend's **sharp money and pro-signal alerts** even better ("Sharp money alert: $15K on the under").

**10. OddsJam: "This guy won no matter what happened" (relaunch)**
- **Ad ID:** 1857891308958690, rank 1 at 6 d.
- **Hook (spoken):** "This guy won no matter what happened in the first quarter of the Celtics-Sixers."
- **Evidence:** the same H3 hook lost in September on NFL games (1574784354660095, 4554055164866931: 8–9 d). It is now OddsJam's top-impression ad on an NBA game [O].
- **Lesson [I]:** sport and recency matter more than the hook. Hooks are worth retesting each season.
- **How to beat it:** a third-person proof hook on a promo conversion.

**11. Linemate: "How are people spotting NBA props that haven't missed yet?"**
- **Ad ID:** 1395804959209935 + 9 (10 IDs, 9 videos, launched 10-24/26).
- **0–3 s hook:** NBA highlight footage, a basketball flying through question marks, and the caption "HOW ARE PEOPLE SPOTTING NBA PROPS THAT HAVEN'T MISSED YET THIS SEASON?" in green and red.
- **Angle:** curiosity question, then a cheat-sheet demo.
- **Evidence:** **D** 10 IDs in 3 days, a new-season scale-up [I].
- **How to beat it:** use the curiosity-question frame, but answer with a price edge, not "100% hit rate". Hit-rate claims are what got Outlier banned.

**12. Juice Reel: "Find the few pick sellers who actually win" + auto-tail**
- **Ad IDs:** 1643820760952279 (rank 4), 1146084687902097 (rank 5).
- **0–3 s hook:**
  - Visual: a young creator in an Eagles jersey under fake tout cards ("CAPPER_KING: NFL 10-0 THIS WEEK 🔥🔥"). The caption "Most NFL pick sellers **aren't winning**", then a ranked leaderboard.
  - Spoken: "I'm going to show you exactly how automated sports picks work."
- **Angle:** copy the verified winners automatically.
- **How to beat it:** BetFriend's pro bettor signals tool, with "the 1% who beat the closing line".

**13. Wise Guy Team: "Every service wants your card first. We do it backwards."**
- **Ad IDs:** 1883584836261303, 952458930820477.
- **0–3 s hook:** a man in a black tee, then a different man in a tan blazer, read the **identical** script in the same AI-rendered sportsbook war room. They are AI avatars [I].
- **Angle:** free first, with all results posted.
- **Emotional trigger:** relief from the subscription-trap fear.
- **Evidence:** 2 avatars × 4 and 2 ad IDs, 11–12 d.
- **Lesson:** an anti-paywall promise lands with cold bettors. BetFriend's 7-day trial can be framed the same way ("Use it all week before you pay").

**14. The Hot Hand: "STOP PAYING FOR PICKS"**
- **Ad IDs:** 2350443975757292, 1109896431529434, 981193461042494.
- **0–3 s hook:** red hand-drawn "NEVER PAY ME ANYTHING / FREE PICKS" beside a column of green-check bet slips.
- **CTA:** Messenger "Send message".
- **Evidence:** 51 IDs, but every one lives 1–8 d, relaunched in daily batches (17 on 10-26) [O].
- **Read [I]:** cheap lead-gen into a DM funnel, constantly re-uploaded, consistent with policy churn. It is an **anti-model** for durable brand building, but proof that "free" plus a slip stack stops the scroll.

**A1. Kalshi: "I made money because it snowed last night"**
- **Ad IDs:** 1072959668952666 (iOS), 1090154740139516 (Android). Same video asset 27809792625329350, same collation ID.
- **0–3 s hook:** a podcast-set two-hander. The first line is an absurd win claim, a cut to the friend's "How?", then the App Store page, then the market UI ($499.98 → $1,261).
- **Angle:** you can profit from everyday things.
- **Emotional trigger:** curiosity gap.
- **Evidence:** **L** 43 d; **R** 6–7.
- **Lesson:** an absurd, specific opening claim followed by a friend's question is the best 3 s hook in the set [I].
- **BetFriend version:** "I made $40 because DraftKings and FanDuel disagreed." "How?"

**A2. Kalshi: "Trade on anything / sports. Live across the U.S." market cards**
- **Ad IDs:** 4592154017778575 (rank 1), 2113101326224523 ("Put real money on the weather", 68 d), 3210928545758290 (gold up or down in 15 minutes, 75 d).
- **Hook:** a single market card with cost and payout ($100 → $294).
- **Evidence:** **D** 20 + 16 + 24 IDs with per-team headlines ("Jacksonville Jaguars -- Next NFL Football Game"), consistent with catalog-style dynamic creative [I]. **L** to 75 d.
- **Lesson:** "cost → payout" in one card is instantly legible to a cold user.

**A3. Polymarket: "Think you know who's winning ___?"**
- **Ad IDs:** 901664116182050 (rank 1, World Cup), 1453173183208842 (Artist of 2026), 1157683096324155 (Oscars), plus Bitcoin and NBA variants.
- **Hook:** a stadium night shot with a market card ("Will Spain win the 2026 FIFA World Cup? Cost $1,240 · To win $7,294").
- **Evidence:** one sentence template with the topic swapped (23 + 18 + 6 + 6 + 6 IDs) [O].
- **Lesson:** a template that swaps in tonight's topic scales without new creative thinking.

**A4. Novig: "POV: your sportsbook every time you want to play"**
- **Ad ID:** 1865955564395349 (rank 3, 20 d).
- **0–3 s hook:** a guy theatrically takes a $100 bill. Caption "Oh you're putting $100 down… it's just **30%**."
- **Angle:** the vig is a hidden tax.
- **Emotional trigger:** indignation.
- **Lesson:** the "book's cut" is a cold-audience concept nobody in the tools category uses. It makes line shopping and +EV obvious without jargon.

**A5. Novig: "Stop just watching the games. Trade them."**
- **Ad IDs:** 2641150729681511 (rank 1), 2045714676083061 (26 d; Sydney Sweeney with a bat, "DEPOSIT $10 GET $50").
- **Evidence:** 17 IDs with 17 different creatives. The headline moved from $25 to $50 credits. A creator ad cites "the viral Sydney Sweeney ad" (1809958243757606).
- **Lesson:** a celebrity plus a hard number offer is the fastest awareness route. Out of BetFriend's budget, but the "watching → doing" line is reusable.

**A6. Kalshi: payout math, "Don't overthink it"**
- **Ad IDs:** 1822717462190341 (street interview at a store: "Who wins the Super Bowl?", "49ers", "Market has them at 9%: $100 pays $1,044.57"), 2193569014538154 ("$25 vs $100 combo", 48 s).
- **Evidence:** **R** 8–12; ended at 17–18 d.
- **Lesson:** real people plus live odds turned into dollars is participatory and fun.

---

## 4. Duplication deep-dive

| Cluster | Copies | What differs between copies | Why it's duplicated (verdict) |
|---|---|---|---|
| **Linemate "Stop Research. Start Winning."** | 68 (54 live) | **60 different videos**, 6+ creators. Same body, headline and CTA. 3 destinations (iTunes 29, web 23, AppsFlyer 16). Batch starts on 10-08, 10-13, 10-22 and 10-26. | **Creative-volume testing at scale.** Copy is held constant while the UGC creator, hook caption and cut vary. Per-OS and web splits multiply the IDs. Batch timing suggests a creator-content pipeline delivering weekly [I]. |
| **Polymarket "If there's a winner, there's a market" / "Think you know who's winning ___?"** | 40 / 23 / 18 / 6 / 6 | Topic swapped (World Cup, Artist, Oscars, Bitcoin, NBA); 2 domains (polymarket.com vs poly.market); starts spread Feb–Apr; up to 62 images. | **Template scaling plus lander and UTM split.** A proven sentence is relaunched per event. Two domains suggest web vs app routing or a domain test [I]. |
| **The Action Network "Football markets are open"** | 36 (all 1 d old on 10-01) | 15 collation groups, up to 4 copies each; 69 images (matchup cards); one affiliate switchboard URL; WhatsApp on 9. | **Advantage+ dynamic creative feeding an affiliate deal.** Matchup cards rotate per game for a Polymarket partner offer ("Deposit $10 get $50", code TANMAX2). Gone by 10-27, and prior research found the landing said "This code isn't valid" [O]. |
| **Kalshi "Trade on anything / sports. Live across the U.S."** | 20 + 16 (21 live) | 4–7 video assets; per-team headlines ("Indianapolis Colts -- Next NFL Football Game"); iOS vs Android links; Install / Download / Shop now CTAs. | **Proven body, scaled into new ad sets, with a catalog-style per-market headline** (team or market feed) and OS splits. Longest copies at 68–69 d prove the body is a winner [I]. |
| **Novig "Stop just watching the games. Trade them."** | 17 (15 live) | 17 collation IDs with distinct creatives (56 images, 3 videos); headline $25 → $50; batch launches on 10-01 and 10-24. | **Winning line kept while creatives and offer change.** The bigger offer was tested and adopted; the 10-24 batch immediately took ranks 1 and 4. |
| **OddsJam "Bet Both Sides" / "Price Gaps"** | 17 + 9 | 5+ landers (`-over-and-under`, `-dustin`, `-both-sides`, `ai-platinum`); one creator per lander; DCO wrappers around a single 20 s video. | **Lander and creator-match testing**: the same video is sent to twin pages to test message match. **Plus failed-ad restructuring**: 1825288881927236 stopped after 1 d but runs inside DCO 1698172121733354. Copy is fixed and creators vary. |
| **PlayerProps.ai "Most awarded…"** | 14 (11 live) | Image vs 8 s video; iOS vs Android sharing collation 1002848225998140; starts 07-22, 08-06, 08-10, 09-08, 09-27. | **Evergreen winner relaunched into new ad sets every few weeks**, split by OS. The 97-day originals were never turned off. |
| **The Hot Hand "STOP PAYING / NEVER PAY…"** | 19 + 14 + 13 + 5 | 13 IDs share **1 collation ID** (identical creative); all live 1–8 d; Messenger CTA; 17 launched on 10-26 alone. | **Mass re-upload of an identical creative across many ad sets**, short-lived, consistent with audience-split brute force or disapproval and account churn [I]. Same pattern as YRL Sports in June (90 ads, ≤ 4 d, a "europe-worldcup" domain). |

Smaller but telling:
- **Flare**: one 10 s video (asset 1748334479571386) appears under 3 different bodies, and the lander moved from runwiththewinners.com to whop.com. That is a primary-text A/B plus a checkout migration.
- **Wise Guy Team**: two AI-avatar renders of one script, each duplicated into 2–4 ad sets. That is a presenter A/B.

---

## 5. Repeatable patterns

| # | Pattern | Examples (ad IDs) | Proxy |
|---|---|---|---|
| P1 | **Attack an enemy (touts, the book, gut picks)** in sentence one | OddsJam 3934320263531311; Juice Reel 1380191140817120, 1577049383583610; Novig 1865955564395349; Hot Hand 2350443975757292; Wise Guy 1883584836261303 | L 53 d; R 1–3 |
| P2 | **Hold the copy, vary the video.** One body over many creatives | Linemate (68 IDs on 60 videos); OddsJam (1 arb body); Novig (17 creatives) | D |
| P3 | **Native-UI hooks**: Snapchat caption bars, lock-screen notifications, App Store cards, market cards | Linemate 1406597501675165; OddsJam 1631510528693064; Kalshi 1072959668952666, 2113101326224523 | R 1–2 |
| P4 | **Dollar-in, dollar-out math on screen** ($100 → $1,044; $10 → $50; "it's 30%") | Kalshi 1822717462190341, 2113101326224523; Polymarket 901664116182050; Novig 1472260898141090 | R 1–12; D |
| P5 | **One worked example of a real game** in under 15 s | OddsJam 2637327576706685, 1631510528693064; Outlier 1467208338772051 | L 53 d |
| P6 | **Free first**: free picks, free week, "no card" | Wise Guy 952458930820477; Hot Hand; PlayerProps 1555696532961020 ("Learn for free"); Flare 1067778092910461 ("It's free") | D |
| P7 | **Cheap statics and 8–10 s motion outlive video** | PlayerProps 2517698648671454 (97 d); Flare 1611633220679010 (81 d); Kalshi 2113101326224523 (68 d) | L |
| P8 | **Swap in tonight's game or season on an evergreen frame** | Polymarket "Think you know who's winning ___"; OddsJam H3 relaunched on NBA (1857891308958690 → rank 1); Outlier per-league | D, R |
| P9 | **Honest or qualifying hooks** ("not a guarantee", "most people quit") | OddsJam 1848819836287088; Dimers 2151353115454307 | D 6+; R 6–11 |
| P10 (avoid) | **Jackpot slips and "100% hit rate"** | Outlier 816854234787019 ("$2 ➡ $28,867"), 4441951222721693: account disabled; Betzy "Five picks. Five wins": dead in ≤ 6 d | L ≈ 0 |

---

## 6. Gaps and white space for BetFriend

| Gap | Evidence it's open | Why it fits a cold audience |
|---|---|---|
| **Bonus-bet / promo converter** | 0 tool ads on it. Discovery for "sportsbook promos" = 0; "bonus bets" = 6, all sportsbooks (Fanatics "Bet $20 get $350"). | Every new sportsbook user already holds bonus money. "Turn your $X bonus into cash" is concrete and needs no betting skill. |
| **All-in-one bundle (25 tools, 1 membership)** | Every advertiser sells one job: arbs, props, records, community or AI chat. | "Stop paying for 5 apps" doubles as an enemy hook (P1) and a reason to believe a brand nobody has heard of. |
| **Sportsbook vs prediction-market price check** | Only Dimers touches it (1654394262963124). Kalshi, Polymarket and Novig are educating millions on "markets". | Rides adjacent spend: "Same game. DraftKings -120. Kalshi 52¢. Which is cheaper?" |
| **Middles** | Zero ads. | "Win both bets" is a novel, demonstrable worked example. |
| **Sharp money / pro signals at TOF** | OddsJam tested it briefly (1151511864057325, ~6 d); Wise Guy mentions it in passing. Nobody uses the lock-screen visual for it. | "Where's the big money going tonight?" is curiosity without a skill barrier. |
| **Live AI game-day second screen** | Flare sells a *chat* second screen (81 d). Rithmm's AI analyst went dark on Meta. | "Turn the game on. Turn BetFriend on." Habit-forming and policy-safe. |
| **The vig as the enemy, for tools** | Only exchange Novig uses it (1865955564395349). | The simplest case for line shopping and +EV. |
| **Transparent proof without a track record** | Juice Reel and OddsJam use synced or third-party records. BetFriend has none yet. | Show the tool finding tonight's gap live on screen, not past wins. |
| **Spanish-language US bettors** | DraftKings runs Spanish ads; no betting-tool advertiser does. | Uncontested inventory at TOF. |

---

## 7. Best five concepts for BetFriend TOF

| Rank | Concept | Built from | Why it wins for a never-heard-of-us audience |
|---|---|---|---|
| **1** | **"Your bonus bet is worth cash." A worked promo conversion.** Creator opens a real $250 bonus, BetFriend's promo converter picks the hedge, and the screen shows "$250 bonus → $178 cash". 30–40 s, then the 7-day trial. | OddsJam's worked example (53 d), Kalshi's dollar math, a white-space job | A tangible dollar outcome in 3 s, for money viewers already hold. Nobody else runs it. It is the cleanest first win before upselling arbs and +EV. |
| **2** | **"Since when is this a thing?" × 25 tools.** A UGC volume engine: 20–40 creator reveals, each discovering one tool (middles, sharp money, arb, parlay builder, AI picks). One body ("25 betting tools. One app. 7 days free."), many videos, Snapchat-caption native style. | Linemate (68 IDs on 60 videos, rank 1) | Lets Meta find the winning tool and creator for us. The breadth is BetFriend's moat and doubles as a tool-demand test. |
| **3** | **"Your sportsbook takes a cut you can't see."** A skit or POV on the vig, then BetFriend showing the best price across books and prediction markets on tonight's game. | Novig's vig POV (rank 3), Dimers' market-price angle, Kalshi's payout cards | An enemy hook (P1) plus pure education. Rides the cold-audience awareness Kalshi and Polymarket are paying for. |
| **4** | **"Watching sports won't make you money."** A pro or ex-trader podcast clip, anti-tout, ending on one live +EV number from the app. | OddsJam's longest live ads (53 d) | The most durable creative in the category. Our version adds the product proof that OddsJam's clips lack. |
| **5** | **Lock-screen "Sharp money alert" and "Injury just dropped" notification hook** for pro signals and live AI analysis: push notifications as captions, then the app. Plus a cheap static and 8 s motion twin ("25 tools. 1 membership. 7 days free.") for long-tail placements. | OddsJam 1631510528693064 (rank 2), PlayerProps statics (97 d), Flare static (81 d) | A native, thumb-stopping UI device. Statics are the longest-lived and cheapest format, so they keep frequency up while video tests run. |

**Execution rules, from the evidence:**
- Hold one body per concept and vary creators.
- Burn in 21+ and 1-800-GAMBLER from frame 1 (OddsJam does).
- Swap the game weekly (P8).
- Never use jackpot slips, "100% hit rate" or "guaranteed" (Outlier was disabled).
- Lead with the free trial and a dollar outcome, not $199.99. Mention standalone plans "from $29.99" only on the lander.
- Treat 30+ days live with stable or rising `impr_rank` as our own "scale it" signal, mirroring PlayerProps and OddsJam.
